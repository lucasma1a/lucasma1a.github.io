<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora em PHP</title>
</head>

<body>
   

    <form action="calculadora.php" method="post">
        <div class="calcu">
            <h1>Calculadora em PHP</h1>

            <br />

            <label for="txtnm1:"> Digite um número: </label>
            <input type="text" name="txtnm1" id="txtnm1"/>

            <br />s

            <label for="txtnm2">Digite mais um número: </label>
            <input type="text" name="txtnm2" id="txtnm2"/>

            <br />

            <button type="submit" name="btncalcu" value="+">+</button>
            <button type="submit" name="btncalcu" value="-">-</button>
            <button type="submit" name="btncalcu" value="*">x</button>
            <button type="submit" name="btncalcu" value="/">:</button>
            <input type="reset" name="btnlimpa" value="C">

                <br />

                <label for="resultado">O resultado será:</label>
                <input type="text" id="resultado" name="resultado">
        </div>

    </form>

    <?php
function calcular()
        {
            $btncc=$_POST['btncalcu'];
            $n1=$_POST['txtnm1'];
            $n2=$_POST['txtnm2'];
            echo "<script language='JavaScript'>document.getElementById('txnm1').value=$n1;</script>";
            echo "<script language='JavaScript'>document.getElementById('txtnm2').value=$n2;</script>";
            
            if ($n1=='')
                $n1=0;
 
            if ($n2=='')
                $n2=0;
            
            if ($n2==0)
            $btncc='Div/0!';
 
            switch ($btncc){
            case "+": 
                $btncc = $n1 + $n2;
                break;
            case "-": 
                $btncc = $n1 - $n2;
                break;
            case "/":
                $btncc = $n1 / $n2;
                break;
            case "*":
                $btncc = $n1 * $n2;
                break;
            };
            
            echo "<script language='JavaScript'>document.getElementById('resultado').value='$btncc';</script>";
        }
 
        calcular(); //chamada à função criada
        ?>
</body>

</html>